package com.example.apk1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
